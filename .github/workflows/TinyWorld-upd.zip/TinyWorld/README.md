# Tiny 3D World: Android app

The game is in `app/src/main/assets/index.html`. The app has no internet permission and runs fully offline.
It opens in landscape. To allow portrait, change `sensorLandscape` to `fullSensor` in `AndroidManifest.xml`.

## Easiest: build online with GitHub (free)
1. Create a new repository on github.com and upload everything in this folder (keep the folder structure, including `.github`).
2. Open the repository's **Actions** tab, pick **Build APK**, and run it (it also runs on every upload).
3. When it finishes, open the run and download the **TinyWorld-APK** artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and install it (allow "install unknown apps" if asked).

## Or build on your computer
1. Run `sh get-libs.sh` once (needs internet) to download the three.js files into the app.
2. Open this folder in Android Studio (JDK 17) and run **Build > Build APK(s)**.
